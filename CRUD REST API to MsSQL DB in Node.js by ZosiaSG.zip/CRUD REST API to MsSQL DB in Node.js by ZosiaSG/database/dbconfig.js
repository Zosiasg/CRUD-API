const config = {
    user : 'API_user',
    password : 'admin',
    server: 'localhost',
    database: 'Bookstore',
    trustServerCertificate: true,
    options:{
        trustedConnection: true,
        enableArithAort : true,
        instancename : 'SQLEXPRESS'
    },
    port : 1433
}
export default config;