// class Books {
//     constructor(BookId, Author, Title, PublishedDate, PublishedBy) {
//         this.BookId = BookId;
//         this.Author = Author;
//         this.Title = Title;
//         this.PublishedDate = PublishedDate;
//         this.PublishedBy = PublishedBy;
//     }
// } 

// export default Books;