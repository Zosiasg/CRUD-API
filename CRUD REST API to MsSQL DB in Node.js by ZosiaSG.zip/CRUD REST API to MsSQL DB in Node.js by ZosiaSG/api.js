import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import booksRoutes from './routes/books.js';
//import Books from './books.js';

const app = express();
const PORT = 8888;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use('/books', booksRoutes); 
//specifying '/books' as the first parameter sets the starting path for all the routes defined in the books.js file

app.get('/', (req, res) => res.send('Hello from Bookstore homepage!'));

app.listen(PORT, () => console.log(`Server running on port: http://localhost:${PORT}`));