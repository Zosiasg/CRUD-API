import express from 'express';
import { addBook, deleteBook, getBook, getBooks, patchBook } from '../controllers/books.js';

const router = express.Router(); 

router.post("/", addBook);

router.get("/", getBooks);

router.get('/:id', getBook);

router.delete('/:id', deleteBook);

router.patch('/:id', patchBook);

export default router;