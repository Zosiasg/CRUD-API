import config from '../database/dbconfig.js';
import sql from 'mssql';

async function getBooks(){
    try{
        let pool = await sql.connect(config);
        let books = await pool.request().query("SELECT * from Books");
        return books.recordsets;
    }
    catch (error){
        console.log(error);
    }
}

async function getBook(BookId){
    try{
        let pool = await sql.connect(config);
        let book = await pool.request()
        .input('input_parameter', sql.Int, BookId)
        .query("SELECT * from Books where BookId = @input_parameter");
        return book.recordsets;
    }
    catch (error){
        console.log(error);
    }
}

async function deleteBook(BookId){
    try{
        let pool = await sql.connect(config);
        let book = await pool.request()
        .input('input_parameter', sql.Int, BookId)
        .query("delete from Books where BookId = @input_parameter");
        return book.recordsets;
    }
    catch (error){
        console.log(error);
    }
}

async function addBook(book) {
try {
    let pool = await sql.connect(config);
    let insertBook = await pool.request()
    .input('Author', sql.VarChar, book.Author)
    .input('Title', sql.VarChar, book.Title)
    .input('PublishedDate', sql.Date, book.PublishedDate)
    .input('PublishedBy', sql.VarChar, book.PublishedBy)
    .query("insert into Books(Author, Title, PublishedDate, PublishedBy) values (@Author, @Title, @PublishedDate, @PublishedBy)");
    return insertBook.recordsets;
}
catch (err) {
    console.log(err);
}
}

// async function updateBook(BookId, What, Parameter) {
//     try{
//         let pool = await sql.connect(config);
//         console.log(What);
//         let book = await pool.request()
//         .input('BookId', sql.Int, BookId)
//         .input('Parameter', sql.VarChar, Parameter)
//         .input('What', sql.NVarChar, What)
//         .query("update Books set @What = @Parameter where BookId = @BookId");
//         return book.recordsets;
//     }
//     catch (error){
//         console.log(error);
//     }
// }

async function updateBookAuthor(BookId, Parameter) {
    try{
        let pool = await sql.connect(config);
        let book = await pool.request()
        .input('BookId', sql.Int, BookId)
        .input('Parameter', sql.VarChar, Parameter)
        .query("update Books set Author = @Parameter where BookId = @BookId");
        return book.recordsets;
    }
    catch (error){
        console.log(error);
    }
}

async function updateBookTitle(BookId, Parameter) {
    try{
        let pool = await sql.connect(config);
                let book = await pool.request()
        .input('BookId', sql.Int, BookId)
        .input('Parameter', sql.VarChar, Parameter)
        .query("update Books set Title = @Parameter where BookId = @BookId");
        return book.recordsets;
    }
    catch (error){
        console.log(error);
    }
}

async function updateBookPublishedBy(BookId, Parameter) {
    try{
        let pool = await sql.connect(config);
                let book = await pool.request()
        .input('BookId', sql.Int, BookId)
        .input('Parameter', sql.VarChar, Parameter)
        .query("update Books set PublishedBy = @Parameter where BookId = @BookId");
        return book.recordsets;
    }
    catch (error){
        console.log(error);
    }
}

async function updateBookPublishedDate(BookId, Parameter) {
    try{
        let pool = await sql.connect(config);
                let book = await pool.request()
        .input('BookId', sql.Int, BookId)
        .input('Parameter', sql.Date, Parameter)
        .query("update Books set PublishedDate = @Parameter where BookId = @BookId");
        return book.recordsets;
    }
    catch (error){
        console.log(error);
    }
}

export default {
    getBooks : getBooks,
    getBook : getBook,
    addBook : addBook,
    deleteBook : deleteBook,
    updateBookAuthor : updateBookAuthor,
    updateBookTitle : updateBookTitle,
    updateBookPublishedDate : updateBookPublishedDate,
    updateBookPublishedBy : updateBookPublishedBy
}