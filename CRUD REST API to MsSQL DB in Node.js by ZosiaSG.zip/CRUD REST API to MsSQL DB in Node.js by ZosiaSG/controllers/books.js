import dboperations from "../dboperations/books.js";

export const getBooks = (request, response) => {
    dboperations.getBooks().then(result => {
        response.json(result[0]);
    })
}

export const addBook = (request, response) => {
    let book = {...request.body}
    dboperations.addBook(book).then(result => {
        response.json(result[0]);
    })
    response.send(`${book.Title} by ${book.Author} has been added to the database`);
}

export const getBook = (request, response) => {
    dboperations.getBook(request.params.id).then(result => {
        response.json(result[0]);
    })
}

export const deleteBook = (request, response) => {
    dboperations.deleteBook(request.params.id).then(result => {
        response.json(result[0]);
    })
    response.send(`Book (Id:${request.params.id}) has been deleted from the database`);
}

export const patchBook = (request, response) => {
    const { id } = request.params;
    const { Author, Title, PublishedDate, PublishedBy } = request.body;
    if(Author) { dboperations.updateBookAuthor(id, Author); };
    if(Title) { dboperations.updateBookTitle(id, Title); };
    if(PublishedDate) { dboperations.updateBookPublishedDate(id, PublishedDate); };
    if(PublishedBy) { dboperations.updateBookPublishedBy(id, PublishedBy); };
    response.send(`Book (Id:${id}) has been updated`);
}